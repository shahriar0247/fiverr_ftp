def get_all_folders():
    pass